This directory is reserved for server to store received files.

This file is a placeholder.
